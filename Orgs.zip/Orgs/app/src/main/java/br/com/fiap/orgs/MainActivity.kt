package br.com.fiap.orgs

import android.app.Activity
import android.os.Bundle
import android.os.PersistableBundle
import android.widget.TextView

// Activity é pai da MainActivity, onde a Main herda tudo que Activity tem
class MainActivity : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
    }
}